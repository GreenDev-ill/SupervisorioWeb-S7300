import React, { useState, useEffect } from 'react';
import { CheckCircle, AlertCircle } from 'lucide-react';

interface StatusIndicatorProps {
  status: 'ok' | 'alarm';
  size?: 'sm' | 'md' | 'lg' | 'xl';
}

export const StatusIndicator: React.FC<StatusIndicatorProps> = ({ 
  status, 
  size = 'md' 
}) => {
  const [animationToggle, setAnimationToggle] = useState(true);

  useEffect(() => {
    const animationTimer = setInterval(() => {
      setAnimationToggle(prev => !prev);
    }, 1500);

    return () => clearInterval(animationTimer);
  }, []);

  const isOk = status === 'ok';
  const sizeClasses = {
    sm: 'w-6 h-6',
    md: 'w-8 h-8',
    lg: 'w-12 h-12',
    xl: 'w-16 h-16'
  };
  
  const iconSizes = {
    sm: 16,
    md: 20,
    lg: 28,
    xl: 36
  };

  const baseColor = isOk ? 'bg-green-500' : 'bg-red-500';
  const pulseColor = isOk ? 'bg-green-400' : 'bg-red-400';
  
  return (
    <div className="relative">
      <div className={`
        ${sizeClasses[size]} 
        rounded-full 
        border-2 
        border-gray-600 
        ${animationToggle ? `${pulseColor} animate-pulse` : baseColor} 
        transition-all 
        duration-700
        shadow-lg
      `}>
      </div>
      <div className={`absolute inset-0 flex items-center justify-center ${sizeClasses[size]}`}>
        {isOk ? (
          <CheckCircle className="text-white opacity-90" size={iconSizes[size]} />
        ) : (
          <AlertCircle className="text-white opacity-90" size={iconSizes[size]} />
        )}
      </div>
    </div>
  );
};