import React from 'react';
import { StatusIndicator } from './StatusIndicator';
import { Header } from './Header';

interface ProducaoPageProps {
  onNavigate: (page: string) => void;
  currentPage: string;
}

export function ProducaoPage({ onNavigate, currentPage }: ProducaoPageProps) {
  const zones = [
    { id: 1, name: 'Zona Safety 1', status: 'ok' as const },
    { id: 2, name: 'Zona Safety 2', status: 'ok' as const }
  ];

  // Dados de produção por hora para cada turno
  const turnoData = [
    {
      turno: 'Turno T4',
      inicio: '05:00',
      fim: '13:00',
      meta: 1000,
      horas: [125, 124, 128, 122, 130, 125, 127, 126],
    },
    {
      turno: 'Turno T5',
      inicio: '13:00',
      fim: '22:00',
      meta: 1000,
      horas: [130, 128, 132, 127, 129, 131, 125, 122],
    },
    {
      turno: 'Turno T6',
      inicio: '22:00',
      fim: '05:00',
      meta: 800,
      horas: [95, 97, 93, 96, 94, 98, 92, 0],
    },
  ];

  const calcularTotal = (horas: number[]) => {
    return horas.reduce((acc, val) => acc + val, 0);
  };

  const calcularEficiencia = (total: number, meta: number) => {
    return ((total / meta) * 100).toFixed(1) + '%';
  };

  return (
    <div className="w-screen h-screen bg-[#c8b899] overflow-hidden">
      <div className="w-full h-full px-8 py-6 flex flex-col">
        {/* Header - Fixed height */}
        <Header currentPage={currentPage} onNavigate={onNavigate} />

        {/* Page Title */}
        <div className="bg-[#6b7ba8] border border-black p-6 mb-6 text-center h-20 flex items-center justify-center">
          <h2 className="text-white text-2xl font-semibold">Controle de Produção - Produção por Hora</h2>
        </div>

        {/* Main Content Area */}
        <div className="bg-white border border-black mb-6 flex-1 flex flex-col overflow-auto">
          <div className="p-6">
            <table className="w-full border-collapse">
              <thead>
                <tr>
                  <th className="border-2 border-black bg-[#6b7ba8] text-white p-3 text-lg"></th>
                  {turnoData.map((turno, index) => (
                    <th key={index} className="border-2 border-black bg-[#6b7ba8] text-white p-3 text-lg">
                      {turno.turno}
                      <div className="text-sm mt-1">({turno.inicio} - {turno.fim})</div>
                    </th>
                  ))}
                </tr>
              </thead>
              <tbody>
                {/* Linhas de produção por hora */}
                {Array.from({ length: 8 }, (_, horaIndex) => (
                  <tr key={horaIndex}>
                    <td className="border-2 border-black bg-gray-100 p-3 text-lg">
                      {horaIndex + 1}ª Hora
                    </td>
                    {turnoData.map((turno, turnoIndex) => (
                      <td key={turnoIndex} className="border-2 border-black bg-[#8ba82c] text-center p-3 text-lg">
                        {turno.horas[horaIndex]}
                      </td>
                    ))}
                  </tr>
                ))}
                
                {/* Linha de TOTAL */}
                <tr>
                  <td className="border-2 border-black bg-gray-200 p-3 text-lg">
                    TOTAL
                  </td>
                  {turnoData.map((turno, turnoIndex) => (
                    <td key={turnoIndex} className="border-2 border-black bg-yellow-300 text-center p-3 text-lg">
                      {calcularTotal(turno.horas)}
                    </td>
                  ))}
                </tr>

                {/* Linha de META */}
                <tr>
                  <td className="border-2 border-black bg-gray-200 p-3 text-lg">
                    META
                  </td>
                  {turnoData.map((turno, turnoIndex) => (
                    <td key={turnoIndex} className="border-2 border-black bg-blue-100 text-center p-3 text-lg">
                      {turno.meta}
                    </td>
                  ))}
                </tr>

                {/* Linha de EFICIÊNCIA */}
                <tr>
                  <td className="border-2 border-black bg-gray-200 p-3 text-lg">
                    EFICIÊNCIA
                  </td>
                  {turnoData.map((turno, turnoIndex) => {
                    const total = calcularTotal(turno.horas);
                    const eficiencia = calcularEficiencia(total, turno.meta);
                    const eficienciaNum = parseFloat(eficiencia);
                    return (
                      <td 
                        key={turnoIndex} 
                        className={`border-2 border-black text-center p-3 text-lg ${
                          eficienciaNum >= 100 ? 'bg-green-200 text-green-800' : 
                          eficienciaNum >= 95 ? 'bg-blue-100 text-blue-800' : 'bg-red-200 text-red-800'
                        }`}
                      >
                        {eficiencia}
                      </td>
                    );
                  })}
                </tr>
              </tbody>
            </table>
          </div>
        </div>

        {/* Bottom Status Bar - Fixed height */}
        <div className="bg-gray-200 border border-black p-6 flex justify-between items-center h-24">
          <div className="flex items-center gap-12">
            {zones.map((zone) => (
              <div key={zone.id} className="flex items-center gap-6">
                <span className="text-xl font-semibold">{zone.name}</span>
                <StatusIndicator status={zone.status} size="lg" />
              </div>
            ))}
          </div>
          
          <div className="flex items-center gap-4">
            <span className="text-xl font-semibold text-red-600"> All Rights Reserved - Ronan H. Medeiros</span>
          </div>
        </div>
      </div>
    </div>
  );
}
