import React, { useState, useEffect } from 'react';
import { CheckCircle } from 'lucide-react';
import logo from 'figma:asset/4b7c6bd17971dfa78338ef3d300dee168a57bb2c.png';

interface HeaderProps {
  currentPage: string;
  onNavigate: (page: string) => void;
}

export function Header({ currentPage, onNavigate }: HeaderProps) {
  const [currentTime, setCurrentTime] = useState(new Date());

  useEffect(() => {
    const timer = setInterval(() => {
      setCurrentTime(new Date());
    }, 1000);

    return () => clearInterval(timer);
  }, []);

  const formatDateTime = (date: Date) => {
    return date.toLocaleString('pt-BR', {
      day: '2-digit',
      month: '2-digit',
      year: 'numeric',
      hour: '2-digit',
      minute: '2-digit',
      second: '2-digit'
    }).replace(',', ' ');
  };

  return (
    <div className="bg-gray-200 border border-black p-6 mb-6 flex justify-between items-center h-20">
      <div className="flex items-center gap-6">
        <img src={logo} alt="Whirlpool" className="h-14 object-contain" />
        <h1 className="text-2xl font-semibold"> Supervisório Web Separador L9 </h1>
        <div className="w-12 h-12 bg-green-500 border border-black flex items-center justify-center">
          <CheckCircle className="w-7 h-7 text-white" />
        </div>
        <div className="flex gap-3">
          <button 
            onClick={() => onNavigate('home')}
            className={`px-6 py-2 border-2 border-black transition-colors ${
              currentPage === 'home' ? 'bg-[#6b7ba8] text-white' : 'bg-gray-300 hover:bg-gray-400'
            }`}
          >
            Home
          </button>
          <button 
            onClick={() => onNavigate('layout')}
            className={`px-6 py-2 border-2 border-black transition-colors ${
              currentPage === 'layout' ? 'bg-[#6b7ba8] text-white' : 'bg-gray-300 hover:bg-gray-400'
            }`}
          >
            Layout
          </button>
          <button 
            onClick={() => onNavigate('leitura')}
            className={`px-6 py-2 border-2 border-black transition-colors ${
              currentPage === 'leitura' ? 'bg-[#6b7ba8] text-white' : 'bg-gray-300 hover:bg-gray-400'
            }`}
          >
            Leitura Código
          </button>
          <button 
            onClick={() => onNavigate('producao')}
            className={`px-6 py-2 border-2 border-black transition-colors ${
              currentPage === 'producao' ? 'bg-[#6b7ba8] text-white' : 'bg-gray-300 hover:bg-gray-400'
            }`}
          >
            Produção
          </button>
        </div>
      </div>
      <div className="text-2xl font-mono">
        {formatDateTime(currentTime)}
      </div>
    </div>
  );
}
