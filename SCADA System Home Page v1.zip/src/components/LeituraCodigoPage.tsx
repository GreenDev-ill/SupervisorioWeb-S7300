import React from 'react';
import { Barcode } from 'lucide-react';
import { StatusIndicator } from './StatusIndicator';
import { Header } from './Header';

interface LeituraCodigoPageProps {
  onNavigate: (page: string) => void;
  currentPage: string;
}

export function LeituraCodigoPage({ onNavigate, currentPage }: LeituraCodigoPageProps) {

  const zones = [
    { id: 1, name: 'Zona Safety 1', status: 'ok' as const },
    { id: 2, name: 'Zona Safety 2', status: 'ok' as const }
  ];

  const recentScans = [
    { id: 1, codigo: 'BAR123456789', produto: 'Produto A', hora: '14:23:45', data: '16/10/2025', status: 'OK' },
    { id: 2, codigo: 'BAR987654321', produto: 'Produto B', hora: '14:22:30', data: '16/10/2025', status: 'OK' },
    { id: 3, codigo: 'BAR555666777', produto: 'Produto C', hora: '14:21:15', data: '16/10/2025', status: 'OK' },
    { id: 4, codigo: 'BAR111222333', produto: 'Produto D', hora: '14:20:00', data: '16/10/2025', status: 'ERRO' },
    { id: 5, codigo: 'BAR444555666', produto: 'Produto E', hora: '14:18:45', data: '16/10/2025', status: 'OK' }
  ];

  return (
    <div className="w-screen h-screen bg-[#c8b899] overflow-hidden">
      <div className="w-full h-full px-8 py-6 flex flex-col">
        {/* Header - Fixed height */}
        <Header currentPage={currentPage} onNavigate={onNavigate} />

        {/* Page Title */}
        <div className="bg-[#6b7ba8] border border-black p-6 mb-6 text-center h-20 flex items-center justify-center">
          <h2 className="text-white text-2xl font-semibold">Sistema de Leitura de Código de Barras</h2>
        </div>

        {/* Main Content Area */}
        <div className="bg-white border border-black mb-6 flex-1 flex flex-col overflow-hidden">
          {/* Scanner Status Panel */}
          <div className="bg-[#8ba82c] border-b border-black p-6 flex items-center justify-between h-28">
            <div className="flex items-center gap-6">
              <Barcode className="w-16 h-16 text-white" />
              <div>
                <div className="text-white text-xl">Scanner Ativo</div>
                <div className="text-white text-lg">Última leitura: 14:23:45</div>
              </div>
            </div>
            <div className="flex items-center gap-4">
              <span className="text-white text-xl">Status do Scanner:</span>
              <StatusIndicator status="ok" size="lg" />
            </div>
          </div>

          {/* Recent Scans Table */}
          <div className="flex-1 overflow-auto">
            <table className="w-full">
              <thead className="sticky top-0">
                <tr className="bg-[#6b7ba8] text-white h-16">
                  <th className="border border-black p-4 text-left w-24 text-lg">Id</th>
                  <th className="border border-black p-4 text-left text-lg">Código de Barras</th>
                  <th className="border border-black p-4 text-left text-lg">Produto</th>
                  <th className="border border-black p-4 text-left w-32 text-lg">Hora</th>
                  <th className="border border-black p-4 text-left w-32 text-lg">Data</th>
                  <th className="border border-black p-4 text-left w-32 text-lg">Status</th>
                </tr>
              </thead>
              <tbody>
                {recentScans.map((scan) => (
                  <tr key={scan.id} className="even:bg-gray-50 hover:bg-blue-50 h-16">
                    <td className="border border-gray-300 p-4 text-lg">{scan.id.toString().padStart(3, '0')}</td>
                    <td className="border border-gray-300 p-4 text-lg font-mono">{scan.codigo}</td>
                    <td className="border border-gray-300 p-4 text-lg">{scan.produto}</td>
                    <td className="border border-gray-300 p-4 text-lg font-mono">{scan.hora}</td>
                    <td className="border border-gray-300 p-4 text-lg font-mono">{scan.data}</td>
                    <td className={`border border-gray-300 p-4 text-lg ${
                      scan.status === 'OK' ? 'text-green-600' : 'text-red-600'
                    }`}>
                      {scan.status}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>

        {/* Bottom Status Bar - Fixed height */}
        <div className="bg-gray-200 border border-black p-6 flex justify-between items-center h-24">
          <div className="flex items-center gap-12">
            {zones.map((zone) => (
              <div key={zone.id} className="flex items-center gap-6">
                <span className="text-xl font-semibold">{zone.name}</span>
                <StatusIndicator status={zone.status} size="lg" />
              </div>
            ))}
          </div>
          
          <div className="flex items-center gap-4">
            <span className="text-xl font-semibold text-red-600"> All Rights Reserved - Ronan H. Medeiros</span>
          </div>
        </div>
      </div>
    </div>
  );
}
