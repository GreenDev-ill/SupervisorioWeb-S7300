import React from 'react';
import { StatusIndicator } from './StatusIndicator';
import { Header } from './Header';

interface LayoutPageProps {
  onNavigate: (page: string) => void;
  currentPage: string;
}

export function LayoutPage({ onNavigate, currentPage }: LayoutPageProps) {
  const zones = [
    { id: 1, name: 'Zona Safety 1', status: 'ok' as const },
    { id: 2, name: 'Zona Safety 2', status: 'ok' as const }
  ];

  return (
    <div className="w-screen h-screen bg-[#c8b899] overflow-hidden">
      <div className="w-full h-full px-8 py-6 flex flex-col">
        {/* Header - Fixed height */}
        <Header currentPage={currentPage} onNavigate={onNavigate} />

        {/* Page Title */}
        <div className="bg-[#6b7ba8] border border-black p-6 mb-6 text-center h-20 flex items-center justify-center">
          <h2 className="text-white text-2xl font-semibold">Layout do Sistema - Visualização de Equipamentos</h2>
        </div>

        {/* Main Content Area */}
        <div className="bg-white border border-black mb-6 flex-1 p-8 overflow-auto">
          <div className="grid grid-cols-2 gap-8 h-full">
            {/* Left Panel - Equipment Layout */}
            <div className="border-2 border-gray-400 p-6 bg-gray-50">
              <h3 className="text-xl mb-6 bg-[#6b7ba8] text-white p-3 border border-black">
                Diagrama de Equipamentos
              </h3>
              <div className="space-y-4">
                <div className="flex items-center justify-between bg-white border border-black p-4">
                  <span className="text-lg">Girador</span>
                  <StatusIndicator status="ok" size="md" />
                </div>
                <div className="flex items-center justify-between bg-white border border-black p-4">
                  <span className="text-lg">Tombador</span>
                  <StatusIndicator status="ok" size="md" />
                </div>
                <div className="flex items-center justify-between bg-white border border-black p-4">
                  <span className="text-lg">Posto de Leitura de Código</span>
                  <StatusIndicator status="ok" size="md" />
                </div>
                <div className="flex items-center justify-between bg-white border border-black p-4">
                  <span className="text-lg">Dorsal</span>
                  <StatusIndicator status="ok" size="md" />
                </div>
                <div className="flex items-center justify-between bg-white border border-black p-4">
                  <span className="text-lg">Ramal A</span>
                  <StatusIndicator status="ok" size="md" />
                </div>
                <div className="flex items-center justify-between bg-white border border-black p-4">
                  <span className="text-lg">Ramal B</span>
                  <StatusIndicator status="ok" size="md" />
                </div>
                <div className="flex items-center justify-between bg-white border border-black p-4">
                  <span className="text-lg">Ramal C</span>
                  <StatusIndicator status="ok" size="md" />
                </div>
                <div className="flex items-center justify-between bg-white border border-black p-4">
                  <span className="text-lg">Ramal Refugo</span>
                  <StatusIndicator status="ok" size="md" />
                </div>
              </div>
            </div>

            {/* Right Panel - Status Information */}
            <div className="border-2 border-gray-400 p-6 bg-gray-50">
              <h3 className="text-xl mb-6 bg-[#6b7ba8] text-white p-3 border border-black">
                Informações de Status
              </h3>
              <div className="space-y-4">
                <div className="bg-white border border-black p-4">
                  <div className="flex justify-between mb-2">
                    <span className="text-lg">Temperatura:</span>
                    <span className="text-lg">23°C</span>
                  </div>
                </div>
                <div className="bg-white border border-black p-4">
                  <div className="flex justify-between mb-2">
                    <span className="text-lg">Pressão:</span>
                    <span className="text-lg">4.5 bar</span>
                  </div>
                </div>
                <div className="bg-white border border-black p-4">
                  <div className="flex justify-between mb-2">
                    <span className="text-lg">Velocidade:</span>
                    <span className="text-lg">1200 RPM</span>
                  </div>
                </div>
                <div className="bg-white border border-black p-4">
                  <div className="flex justify-between mb-2">
                    <span className="text-lg">Consumo Energia:</span>
                    <span className="text-lg">45.2 kW</span>
                  </div>
                </div>
                <div className="bg-white border border-black p-4">
                  <div className="flex justify-between mb-2">
                    <span className="text-lg">Tempo de Operação:</span>
                    <span className="text-lg">08:45:23</span>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Bottom Status Bar - Fixed height */}
        <div className="bg-gray-200 border border-black p-6 flex justify-between items-center h-24">
          <div className="flex items-center gap-12">
            {zones.map((zone) => (
              <div key={zone.id} className="flex items-center gap-6">
                <span className="text-xl font-semibold">{zone.name}</span>
                <StatusIndicator status={zone.status} size="lg" />
              </div>
            ))}
          </div>
          
          <div className="flex items-center gap-4">
            <span className="text-xl font-semibold text-red-600"> All Rights Reserved - Ronan H. Medeiros</span>
          </div>
        </div>
      </div>
    </div>
  );
}
