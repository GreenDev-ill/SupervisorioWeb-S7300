import React, { useState } from 'react';
import { StatusIndicator } from './components/StatusIndicator';
import { Header } from './components/Header';
import { LayoutPage } from './components/LayoutPage';
import { LeituraCodigoPage } from './components/LeituraCodigoPage';
import { ProducaoPage } from './components/ProducaoPage';

export default function App() {
  const [currentPage, setCurrentPage] = useState<string>('home');

  const zones = [
    { id: 1, name: 'Zona Safety 1', status: 'ok' as const },
    { id: 2, name: 'Zona Safety 2', status: 'ok' as const }
  ];

  // Sample alarms - can be empty or filled (10 rows total)
  const alarms = [
    { id: '001', description: 'Sistema em operação normal', classe: 'INFO', hora: '11:23:00', data: '01/14/2025' },
    { id: '002', description: 'Sensor de temperatura OK', classe: 'STATUS', hora: '11:22:45', data: '01/14/2025' },
    { id: '003', description: 'Pressão dentro dos parâmetros', classe: 'STATUS', hora: '11:22:30', data: '01/14/2025' }
  ];

  // Render different pages based on currentPage state
  if (currentPage === 'layout') {
    return <LayoutPage onNavigate={setCurrentPage} currentPage={currentPage} />;
  }

  if (currentPage === 'leitura') {
    return <LeituraCodigoPage onNavigate={setCurrentPage} currentPage={currentPage} />;
  }

  if (currentPage === 'producao') {
    return <ProducaoPage onNavigate={setCurrentPage} currentPage={currentPage} />;
  }

  // Home page
  return (
    <div className="w-screen h-screen bg-[#c8b899] overflow-hidden">
      <div className="w-full h-full px-8 py-6 flex flex-col">
        {/* Header - Fixed height */}
        <Header currentPage={currentPage} onNavigate={setCurrentPage} />

        {/* Status Panel - Fixed height */}
        <div className="bg-[#8ba82c] border border-black p-6 mb-6 text-center h-20 flex items-center justify-center">
          <h2 className="text-white text-2xl font-semibold">Painel Em Ciclo Automático</h2>
        </div>

        {/* Alarm List Table - Flexible height to fill remaining space */}
        <div className="bg-white border border-black mb-6 flex-1 flex flex-col">
          {/* Table Header */}
          <div className="bg-[#6b7ba8] border-b border-black p-4">
            <h3 className="text-white text-xl font-semibold">Alarmes Ativos</h3>
          </div>
          <table className="w-full h-full">
            <thead className="h-16">
              <tr className="bg-[#6b7ba8] text-white h-16">
                <th className="border border-black p-4 text-left w-24 text-lg">Id</th>
                <th className="border border-black p-4 text-left text-lg">Descrição</th>
                <th className="border border-black p-4 text-left w-32 text-lg">Classe</th>
                <th className="border border-black p-4 text-left w-32 text-lg">Hora</th>
                <th className="border border-black p-4 text-left w-32 text-lg">Data</th>
              </tr>
            </thead>
            <tbody className="flex-1">
              {Array.from({ length: 10 }, (_, index) => {
                const alarm = alarms[index];
                return (
                  <tr key={index} className="even:bg-gray-50 hover:bg-blue-50 h-16">
                    <td className="border border-gray-300 p-4 text-lg">{alarm?.id || ''}</td>
                    <td className="border border-gray-300 p-4 text-lg">{alarm?.description || ''}</td>
                    <td className="border border-gray-300 p-4 text-lg">{alarm?.classe || ''}</td>
                    <td className="border border-gray-300 p-4 text-lg font-mono">{alarm?.hora || ''}</td>
                    <td className="border border-gray-300 p-4 text-lg font-mono">{alarm?.data || ''}</td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>

        {/* Bottom Status Bar - Fixed height */}
        <div className="bg-gray-200 border border-black p-6 flex justify-between items-center h-24">
          <div className="flex items-center gap-12">
            {zones.map((zone) => (
              <div key={zone.id} className="flex items-center gap-6">
                <span className="text-xl font-semibold">{zone.name}</span>
                <StatusIndicator status={zone.status} size="lg" />
              </div>
            ))}
          </div>
          
          <div className="flex items-center gap-4">
            <span className="text-xl font-semibold text-red-600"> All Rights Reserved - Ronan H. Medeiros</span>
          </div>
        </div>
      </div>
    </div>
  );
}
