
  # SCADA System Home Page

  This is a code bundle for SCADA System Home Page. The original project is available at https://www.figma.com/design/bO0TecXaY9XN62fPrbIuaD/SCADA-System-Home-Page.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  